USE [HappyScoopers_Demo]
GO

SELECT * FROM [dbo].[Countries]
SELECT * FROM [dbo].[Provinces]
SELECT * FROM [dbo].[Cities]
SELECT * FROM [Addresses]





























