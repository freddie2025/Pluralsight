Dimension Development
Stacia Misner
www.pluralsight.com


This demonstration assumes that you have installed AdventureWorksDW2008R2 database 
in the local SQL Server 2008 R2 database instance. You can download the database
available from http://msftdbprodsamples.codeplex.com.

In addition, you must execute the ssas-basic-dimension-setup.sql script found
in the ssas-basic-dimension-part-2\begin folder. DO NOT execute this script if you have
already executed the ssas-basic-model-setup.sql script in the ssas-basic-model\begin
folder. The script is included here if you have skipped previous modules.

In SQL Server Management Studio, grant db_datareader permissions to 
the Analysis Services Windows service account with db_datareader
for the ssas-basic-model database after completing the previous step. This step
is not required if you have successfully completed the previous modules.

