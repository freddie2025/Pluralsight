Dimensional Model Development
Stacia Misner
www.pluralsight.com


This demonstration assumes that you have installed AdventureWorksDW2008R2 database 
in the local SQL Server 2008 R2 database instance. You can download the database
available from http://msftdbprodsamples.codeplex.com.

In addition, you must execute the ssas-basic-model-setup.sql script found
in the 02-ssas-basic-model\ssas-basic-model\begin folder.

