﻿using System.Windows;

namespace PeopleViewer
{
    public partial class App : Application
    {

    }
}
