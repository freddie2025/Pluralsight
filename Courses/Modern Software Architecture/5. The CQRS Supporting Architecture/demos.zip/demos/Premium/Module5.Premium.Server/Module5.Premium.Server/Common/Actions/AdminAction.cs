﻿namespace Module5.Premium.Server.Common.Actions
{
    public enum AdminAction
    {
        Unknown = 0,
        ResetDb = 1,
    }
}