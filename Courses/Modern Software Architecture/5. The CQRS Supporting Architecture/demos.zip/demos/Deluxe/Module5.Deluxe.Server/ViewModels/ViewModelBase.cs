﻿
namespace Module5.Deluxe.Server.ViewModels
{
    public class ViewModelBase
    {
        public ViewModelBase()
        {
            Title = "MERLOBOOK";
        }

        public string Title { get; set; }
    }
}