﻿
namespace Merlo.Eda.Infrastructure
{
    public class Message
    {
        public string SagaId { get; protected set; }
    }
}