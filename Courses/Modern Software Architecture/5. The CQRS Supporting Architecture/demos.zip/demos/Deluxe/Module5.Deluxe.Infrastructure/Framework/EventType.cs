﻿namespace Module5.Deluxe.Infrastructure.Framework
{
    public enum EventType
    {
        Unknown = 0,
        BookingCreated = 1,
        BookingRejected = 2
    }
}