﻿namespace Module6.EventSourcing.Infrastructure.Framework
{
    public class Command : Message
    {
    }
}