﻿namespace Module6.EventSourcing.Infrastructure.Framework
{
    public enum EventType
    {
        Unknown = 0,
        BookingCreated = 1,
        BookingRejected = 2
    }
}