﻿
namespace Module6.EventSourcing.Server.ViewModels
{
    public class ViewModelBase
    {
        public ViewModelBase()
        {
            Title = "Module 6";
        }

        public string Title { get; set; }
    }
}