﻿var ROOTSERVER = "";

function book(courtId, hour) {
    $("#hour").val(hour);
    $("#bookingPanel").collapse('show');
}