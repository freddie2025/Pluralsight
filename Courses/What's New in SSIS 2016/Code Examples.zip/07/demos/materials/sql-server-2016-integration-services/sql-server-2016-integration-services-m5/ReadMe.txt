What's New in SQL Server 2016 Integration Services
Stacia Misner Varga
www.pluralsight.com


To follow along with the demonstrations in Module 5, you must have a Microsoft Azure subscription available. 

The Integration Services project requires you to provide your own Azure subscription and application keys. 


Extract the ssis-data.zip file to the c:\ drive. If you place it elsewhere, you must adjust connection managers as needed in various packages.