-- set up the execution
Declare @execution_id bigint
EXEC [SSISDB].[catalog].[create_execution] 
@package_name=N'01-data-flow-error.dtsx', 
@execution_id=@execution_id OUTPUT, 
@folder_name=N'deploy-manage', 
@project_name=N'ssis-2016-deploy-manage', 
@use32bitruntime=False



-- add in the data tap prior to start_execution
EXEC [SSISDB].[catalog].[add_data_tap] 
@execution_id=@execution_id, 
@task_package_path=N'\Package\Data Flow Task',
@dataflow_path_id_string=N'Paths[Derived Column.Derived Column Error Output]',
@data_filename='mydatatap.csv'

-- execute the package
EXEC [SSISDB].[catalog].[start_execution] @execution_id
GO
