use SSISDB;
go

DECLARE @LastExecutionID bigint;
SET @LastExecutionID = 
    (SELECT MAX(operation_id) FROM catalog.operations);

SELECT *
FROM  [catalog].[event_message_context] emc
inner join [catalog].[event_messages] em on 
   emc.[event_message_id] = em.[event_message_id]

-- update with operation_id from package execution
where operation_id in (@LastExecutionID)
