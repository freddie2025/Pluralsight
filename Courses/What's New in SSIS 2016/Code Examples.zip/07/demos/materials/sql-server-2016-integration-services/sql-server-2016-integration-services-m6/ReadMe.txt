What's New in SQL Server 2016 Integration Services
Stacia Misner Varga
www.pluralsight.com


To follow along with the demonstrations in Module 6, you must install the following:

SQL Server 2016 - Download an evaluation edition valid for 180 days from https://www.microsoft.com/en-us/evalcenter/evaluate-sql-server-2016
Installation instructions: https://docs.microsoft.com/en-us/sql/database-engine/install-windows/install-sql-server

    Features to install:
        Database Engine
        Integration Services


SQL Server Management Studio - Release 17.0
https://docs.microsoft.com/en-us/sql/ssms/download-sql-server-management-studio-ssms

SQL Server Data Tools for Visual Studio 2015
https://docs.microsoft.com/en-us/sql/ssdt/download-sql-server-data-tools-ssdt


You must also install some version of AdventureWorks and (any version from AdventureWorks2008R2 to AdventureWorks2014).
You can download the database available from http://msftdbprodsamples.codeplex.com 
or (after CodePlex shuts down on December 15, 2017) download from GitHub. A link is not currently available,
but should appear on the CodePlex site as shut down approaches. 

After restoring the version of AdventureWorks20xx, rename it to AdventureWorks. Else you will need to change
connection managers in the packages to point to your version of this database. Far easier to rename it!

Module 6 requires execution of the sql-server-2016-integration-services-m6-setup.sql script 
(located in the C:\sql-server-2016-integration-services\sql-server-2016-integration-services-m6 folder)

Extract the ssis-data.zip file to the c:\ drive. If you place it elsewhere, you must adjust connection managers as needed in various packages.


