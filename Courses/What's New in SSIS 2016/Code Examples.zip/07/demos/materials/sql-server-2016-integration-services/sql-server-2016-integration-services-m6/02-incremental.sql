Declare @execution_id bigint
EXEC [SSISDB].[catalog].[create_execution] 
@package_name=N'02-extract-product.dtsx', 
@execution_id=@execution_id OUTPUT, 
@folder_name=N'deploy-manage', 
@project_name=N'ssis-2016-deploy-manage', 
@use32bitruntime=False

DECLARE @var int = -1
EXEC [SSISDB].[catalog].[set_object_parameter_value] 
@object_type=30, 
@parameter_name=N'ParentAuditKey', 
@object_name=N'02-extract-product.dtsx', 
@folder_name=N'deploy-manage', 
@project_name=N'ssis-2016-deploy-manage', 
@value_type=V, @parameter_value=@var

EXEC [SSISDB].[catalog].[start_execution] @execution_id
GO

Declare @execution_id bigint
EXEC [SSISDB].[catalog].[create_execution] 
@package_name=N'02-extract-product-category.dtsx', 
@execution_id=@execution_id OUTPUT, 
@folder_name=N'deploy-manage', 
@project_name=N'ssis-2016-deploy-manage', 
@use32bitruntime=False

DECLARE @var int = -1
EXEC [SSISDB].[catalog].[set_object_parameter_value] 
@object_type=30, 
@parameter_name=N'ParentAuditKey', 
@object_name=N'02-extract-product-category.dtsx', 
@folder_name=N'deploy-manage', 
@project_name=N'ssis-2016-deploy-manage', 
@value_type=V, @parameter_value=@var

EXEC [SSISDB].[catalog].[start_execution] @execution_id
GO

Declare @execution_id bigint
EXEC [SSISDB].[catalog].[create_execution] 
@package_name=N'02-extract-product-subcategory.dtsx', 
@execution_id=@execution_id OUTPUT, 
@folder_name=N'deploy-manage', 
@project_name=N'ssis-2016-deploy-manage', 
@use32bitruntime=False

DECLARE @var int = -1
EXEC [SSISDB].[catalog].[set_object_parameter_value] 
@object_type=30, 
@parameter_name=N'ParentAuditKey', 
@object_name=N'02-extract-product-subcategory.dtsx', 
@folder_name=N'deploy-manage', 
@project_name=N'ssis-2016-deploy-manage', 
@value_type=V, @parameter_value=@var

EXEC [SSISDB].[catalog].[start_execution] @execution_id
GO