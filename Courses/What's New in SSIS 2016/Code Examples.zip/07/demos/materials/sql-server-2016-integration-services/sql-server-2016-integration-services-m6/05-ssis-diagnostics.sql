USE SSISDB;
go

DECLARE @LastExecutionID bigint;
SET @LastExecutionID = 
    (SELECT MAX(operation_id) FROM catalog.operations);

--DiagnosticEx
SELECT * FROM catalog.operation_messages
WHERE operation_id = @LastExecutionID;

--Component Data Volume
SELECT package_name, dataflow_path_id_string, SUM(rows_sent) as RowsCnt
FROM catalog.execution_data_statistics
WHERE execution_id = @LastExecutionID
GROUP BY package_name, dataflow_path_id_string;

--Component Execution Statistics
SELECT package_name, subcomponent_name, phase, 
    SUM(DATEDIFF(ms,start_time, end_time)) as ComponentTime,
	DATEDIFF(ms, min(start_time), max(end_time)) as TotalTime
FROM catalog.execution_component_phases
WHERE execution_id = @LastExecutionID
GROUP BY package_name, subcomponent_name, phase
ORDER BY ComponentTime desc;




