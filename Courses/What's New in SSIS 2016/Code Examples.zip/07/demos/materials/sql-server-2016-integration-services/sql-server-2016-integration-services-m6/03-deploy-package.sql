USE SSISDB;
GO

DECLARE @PkgTable catalog.Package_Table_Type ;
DECLARE @op_id as bigint  ;
INSERT INTO @PkgTable 
SELECT 'xml', * FROM OPENROWSET(
    BULK 'C:\sql-server-2016-integration-services\sql-server-2016-integration-services-m7\xml.dtsx', 
	SINGLE_BLOB) pkg ;



exec catalog.deploy_packages
  @folder_name = 'deploy-manage'   
  ,@project_name = 'ssis-2016-deploy-manage'
  ,@packages_table = @PkgTable
  ,@operation_id  = @op_id OUTPUT;