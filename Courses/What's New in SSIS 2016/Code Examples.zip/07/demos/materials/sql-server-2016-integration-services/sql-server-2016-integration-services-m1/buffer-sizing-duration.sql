/****** Script for SelectTopNRows command from SSMS  ******/
SELECT AuditKey, TableName, PkgName, datediff(mi, ExecStartDT, ExecStopDT) as Duration, ExtractRowCnt
  FROM [AdventureWorksDW_demo_etl].[dw].[DimAudit]
  where PkgName = '12b-buffer-sizing'