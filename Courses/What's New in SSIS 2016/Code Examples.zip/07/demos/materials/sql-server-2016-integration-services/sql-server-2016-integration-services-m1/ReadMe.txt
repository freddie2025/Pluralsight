What's New in SQL Server 2016 Integration Services
Stacia Misner Varga
www.pluralsight.com


To follow along with the demonstrations in Modules 1, 2, and 3, you must install the following:

SQL Server 2016 - Download an evaluation edition valid for 180 days from https://www.microsoft.com/en-us/evalcenter/evaluate-sql-server-2016
Installation instructions: https://docs.microsoft.com/en-us/sql/database-engine/install-windows/install-sql-server

    Features to install:
        Database Engine
        Integration Services
        Analysis Services Tabular Instance

SQL Server Management Studio - Release 17.0
https://docs.microsoft.com/en-us/sql/ssms/download-sql-server-management-studio-ssms

SQL Server Data Tools for Visual Studio 2015
https://docs.microsoft.com/en-us/sql/ssdt/download-sql-server-data-tools-ssdt

Optionally - 
    SQL Server Data Tools for Visual Studio 2013
    https://www.microsoft.com/en-us/download/details.aspx?id=42313

    SQL Server Data Tools - Business Intelligence for Visual Studio 2012
    https://www.microsoft.com/en-us/download/details.aspx?id=36843
    (or install from SQL Server 2012 installation media)

You must also install some version of AdventureWorks and (any version from AdventureWorks2008R2 to AdventureWorks2014).
You can download the database available from http://msftdbprodsamples.codeplex.com 
or (after CodePlex shuts down on December 15, 2017) download from GitHub. A link is not currently available,
but should appear on the CodePlex site as shut down approaches. 

After restoring the version of AdventureWorks20xx, rename it to AdventureWorks. Else you will need to change
connection managers in the packages to point to your version of this database. Far easier to rename it!

Extract the ssis-data.zip file to the c:\ drive. If you place it elsewhere, you must adjust connection managers as needed in various packages.

Module 1 requires execution of the sql-server-2016-integration-services-m2-setup.sql script 
(located in the C:\sql-server-2016-integration-services\sql-server-2016-integration-services-m2 folder)

Module 2 also requires restoration of the tabular-2016.abf to an Analysis Services instance 
(assumed to be your local server with TABULAR as intance name... (localhost)\TABULAR)
For instructions, see 
    https://docs.microsoft.com/en-us/sql/analysis-services/multidimensional-models/backup-and-restore-of-analysis-services-databases

Module 2 and Module 3 require installation of Hadoop. You can download a free Hadoop Sandbox from Hortonworks at:
https://hortonworks.com/products/sandbox/

Module 3 reviews the following components:
    Microsoft Connections v4.0 https://www.microsoft.com/en-us/download/details.aspx?id=52950
    SQL Server 2016 Integration Services Is the Microsoft� Connector for SAP BW 
	https://www.microsoft.com/en-us/download/details.aspx?id=52676
    






