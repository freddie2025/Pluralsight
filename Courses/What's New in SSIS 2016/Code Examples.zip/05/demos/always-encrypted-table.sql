Use AdventureWorksDW_demo_stage;
GO

CREATE TABLE [stage].[CreditCard](
	[CreditCardID] [int] NOT NULL,
	[CardType] [nvarchar](50) NOT NULL,
	[CardNumber] [nvarchar](25) 
	COLLATE Latin1_General_BIN2
	ENCRYPTED WITH (ENCRYPTION_TYPE = DETERMINISTIC, 
	    ALGORITHM = 'AEAD_AES_256_CBC_HMAC_SHA_256', COLUMN_ENCRYPTION_KEY = AW_AE_CE) NOT NULL,
	[ExpMonth] [tinyint] NOT NULL,
	[ExpYear] [smallint] NOT NULL,
	[ModifiedDate] [datetime] NOT NULL);
