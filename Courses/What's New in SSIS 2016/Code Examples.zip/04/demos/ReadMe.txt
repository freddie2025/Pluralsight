What's New in SQL Server 2016 Integration Services
Stacia Misner Varga
www.pluralsight.com


Please use the files located in the sql-server-2016-integration-services-m1 folder.

