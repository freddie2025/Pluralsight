﻿using System.Windows.Controls;

namespace State_Design_Pattern.UI
{
    /// <summary>
    /// Interaction logic for StatusPage.xaml
    /// </summary>
    public partial class StatusPage : Page
    {
        public StatusPage()
        {
            InitializeComponent();
        }
    }
}
